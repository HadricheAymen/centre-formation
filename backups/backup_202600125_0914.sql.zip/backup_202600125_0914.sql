-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: centre_formation
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cours`
--

DROP TABLE IF EXISTS `cours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cours` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `coefficient` double DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `nombre_heures` int DEFAULT NULL,
  `titre` varchar(200) NOT NULL,
  `formateur_id` bigint DEFAULT NULL,
  `session_id` bigint DEFAULT NULL,
  `specialite_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK8p1iiglxragmfs464ypmxr5tu` (`code`),
  KEY `FKkl5wxbvjrmbfwt0kqk05bsih7` (`formateur_id`),
  KEY `FKa2x4x4ho7nqnx74scgk77wpea` (`session_id`),
  KEY `FKht9aya4tosrte46kfjbbxb8qs` (`specialite_id`),
  CONSTRAINT `FKa2x4x4ho7nqnx74scgk77wpea` FOREIGN KEY (`session_id`) REFERENCES `sessions_pedagogiques` (`id`),
  CONSTRAINT `FKht9aya4tosrte46kfjbbxb8qs` FOREIGN KEY (`specialite_id`) REFERENCES `specialites` (`id`),
  CONSTRAINT `FKkl5wxbvjrmbfwt0kqk05bsih7` FOREIGN KEY (`formateur_id`) REFERENCES `formateurs` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cours`
--

LOCK TABLES `cours` WRITE;
/*!40000 ALTER TABLE `cours` DISABLE KEYS */;
INSERT INTO `cours` VALUES (1,'SPRING-101',3,'Introduction au développement avec Spring Boot',40,'Framework Spring Boot',2,1,1),(2,'DB-201',2.5,'Conception et optimisation de bases de données',35,'Bases de Données Avancées',3,1,1),(3,'WEB-301',4,'Développement d\'applications web modernes',50,'Développement Web Full Stack',2,1,1),(4,'MGMT-101',2,'Introduction aux concepts de management',30,'Principes de Management',4,1,2),(5,'SALES-101',3,'Stratégies de ventes et de marketing',40,'Ventes et Marketing',4,1,2),(6,'JEE-101',3.5,'Développement d\'applications Java Enterprise Edition',45,'Développement JEE',3,1,1),(7,'DEVOPS-101',2,'Introduction aux principes de DevOps',30,'Introduction au DevOps',2,1,1);
/*!40000 ALTER TABLE `cours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cours_groupe`
--

DROP TABLE IF EXISTS `cours_groupe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cours_groupe` (
  `cours_id` bigint NOT NULL,
  `groupe_id` bigint NOT NULL,
  KEY `FKmxg4j5mjdeko4wp630okoucj5` (`groupe_id`),
  KEY `FKal7cmhtqj3q8x4laqcnwqgvas` (`cours_id`),
  CONSTRAINT `FKal7cmhtqj3q8x4laqcnwqgvas` FOREIGN KEY (`cours_id`) REFERENCES `cours` (`id`),
  CONSTRAINT `FKmxg4j5mjdeko4wp630okoucj5` FOREIGN KEY (`groupe_id`) REFERENCES `groupes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cours_groupe`
--

LOCK TABLES `cours_groupe` WRITE;
/*!40000 ALTER TABLE `cours_groupe` DISABLE KEYS */;
INSERT INTO `cours_groupe` VALUES (1,1),(1,2),(2,1),(3,2),(4,2),(5,1),(6,2),(7,1);
/*!40000 ALTER TABLE `cours_groupe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etudiant_groupe`
--

DROP TABLE IF EXISTS `etudiant_groupe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etudiant_groupe` (
  `etudiant_id` bigint NOT NULL,
  `groupe_id` bigint NOT NULL,
  KEY `FK4dtvlinxlue8bqacpocu5rjb8` (`groupe_id`),
  KEY `FKauflkuexh2ima89feehja50il` (`etudiant_id`),
  CONSTRAINT `FK4dtvlinxlue8bqacpocu5rjb8` FOREIGN KEY (`groupe_id`) REFERENCES `groupes` (`id`),
  CONSTRAINT `FKauflkuexh2ima89feehja50il` FOREIGN KEY (`etudiant_id`) REFERENCES `etudiants` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etudiant_groupe`
--

LOCK TABLES `etudiant_groupe` WRITE;
/*!40000 ALTER TABLE `etudiant_groupe` DISABLE KEYS */;
INSERT INTO `etudiant_groupe` VALUES (5,1),(6,1),(7,2),(8,2);
/*!40000 ALTER TABLE `etudiant_groupe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etudiants`
--

DROP TABLE IF EXISTS `etudiants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etudiants` (
  `adresse` varchar(200) DEFAULT NULL,
  `date_inscription` date NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `matricule` varchar(50) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK7dcho6ioi2rdfjm2fjtsm1xcy` (`matricule`),
  CONSTRAINT `FKsgxlwybt9svpg1vi17i44695h` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etudiants`
--

LOCK TABLES `etudiants` WRITE;
/*!40000 ALTER TABLE `etudiants` DISABLE KEYS */;
INSERT INTO `etudiants` VALUES ('Tunis, Tunisie','2024-09-01','2002-05-15','ETU001','98123456',5),('Sfax, Tunisie','2024-09-01','2003-03-20','ETU002','98234567',6),('Sousse, Tunisie','2024-09-01','2002-11-10','ETU003','98345678',7),('Gabes, Tunisie','2024-09-01','2003-07-25','ETU004','98456789',8);
/*!40000 ALTER TABLE `etudiants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formateurs`
--

DROP TABLE IF EXISTS `formateurs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formateurs` (
  `biographie` varchar(500) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `user_id` bigint NOT NULL,
  `specialite_id` bigint DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  KEY `FKd7c61qqaoxycapn8bt1r7oo8n` (`specialite_id`),
  CONSTRAINT `FKd7c61qqaoxycapn8bt1r7oo8n` FOREIGN KEY (`specialite_id`) REFERENCES `specialites` (`id`),
  CONSTRAINT `FKp0inc84swq2qmogjuftdif2h` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formateurs`
--

LOCK TABLES `formateurs` WRITE;
/*!40000 ALTER TABLE `formateurs` DISABLE KEYS */;
INSERT INTO `formateurs` VALUES ('Formateur expérimenté en développement web','20123456',2,1),('Formatrice spécialisée en bases de données','20234567',3,1),('Formateur expert en gestion et management d\'entreprise','20345678',4,2);
/*!40000 ALTER TABLE `formateurs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupes`
--

DROP TABLE IF EXISTS `groupes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `capacite_max` int DEFAULT NULL,
  `code` varchar(50) NOT NULL,
  `nom` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKd8nfbx3phh5vg1m5shfjo589q` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupes`
--

LOCK TABLES `groupes` WRITE;
/*!40000 ALTER TABLE `groupes` DISABLE KEYS */;
INSERT INTO `groupes` VALUES (1,30,'G1-2024','Groupe 1 - Promotion 2024'),(2,30,'G2-2024','Groupe 2 - Promotion 2024');
/*!40000 ALTER TABLE `groupes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inscriptions`
--

DROP TABLE IF EXISTS `inscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inscriptions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `date_annulation` datetime(6) DEFAULT NULL,
  `date_inscription` datetime(6) NOT NULL,
  `cours_id` bigint NOT NULL,
  `etudiant_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKc84s4jblc1ojd6id8yecxy1k0` (`etudiant_id`,`cours_id`),
  KEY `FKt3re4dbtj2w5601e98q0ohhjl` (`cours_id`),
  CONSTRAINT `FKrbdv2i5mc55pqxpuwt4fgxdbh` FOREIGN KEY (`etudiant_id`) REFERENCES `etudiants` (`user_id`),
  CONSTRAINT `FKt3re4dbtj2w5601e98q0ohhjl` FOREIGN KEY (`cours_id`) REFERENCES `cours` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inscriptions`
--

LOCK TABLES `inscriptions` WRITE;
/*!40000 ALTER TABLE `inscriptions` DISABLE KEYS */;
INSERT INTO `inscriptions` VALUES (1,_binary '',NULL,'2026-01-25 08:07:41.427139',1,5),(2,_binary '',NULL,'2026-01-25 08:07:41.441923',2,5),(3,_binary '',NULL,'2026-01-25 08:07:41.459207',1,6),(4,_binary '',NULL,'2026-01-25 08:07:41.479405',2,6),(5,_binary '',NULL,'2026-01-25 08:07:41.494399',1,7),(6,_binary '',NULL,'2026-01-25 08:07:41.508950',3,7);
/*!40000 ALTER TABLE `inscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notes`
--

DROP TABLE IF EXISTS `notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `commentaire` varchar(500) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `date_evaluation` datetime(6) DEFAULT NULL,
  `type_evaluation` varchar(50) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `valeur` double NOT NULL,
  `cours_id` bigint NOT NULL,
  `etudiant_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKt4e7j2ns59kcyij4w49ktw97k` (`etudiant_id`,`cours_id`,`type_evaluation`),
  KEY `FK6lsdr67qrpvgosk6h0juopvor` (`cours_id`),
  CONSTRAINT `FK2p87f9yfn7wogf1nor0u3etcp` FOREIGN KEY (`etudiant_id`) REFERENCES `etudiants` (`user_id`),
  CONSTRAINT `FK6lsdr67qrpvgosk6h0juopvor` FOREIGN KEY (`cours_id`) REFERENCES `cours` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes`
--

LOCK TABLES `notes` WRITE;
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
INSERT INTO `notes` VALUES (1,'Très bon travail','2026-01-25 08:07:41.526707','2024-11-15 09:00:00.000000','Examen','2026-01-25 08:07:41.526840',16.5,1,5),(2,'Bon projet','2026-01-25 08:07:41.545412','2024-11-20 14:00:00.000000','Projet','2026-01-25 08:07:41.545431',14,2,5),(3,'Bien','2026-01-25 08:07:41.557985','2024-11-15 09:00:00.000000','Examen','2026-01-25 08:07:41.558023',15,1,6);
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seances`
--

DROP TABLE IF EXISTS `seances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seances` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `annulee` bit(1) NOT NULL,
  `date_debut` datetime(6) NOT NULL,
  `date_fin` datetime(6) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `salle` varchar(100) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `cours_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKj9gcar4c2al65bp5okqe6ewvn` (`cours_id`),
  CONSTRAINT `FKj9gcar4c2al65bp5okqe6ewvn` FOREIGN KEY (`cours_id`) REFERENCES `cours` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seances`
--

LOCK TABLES `seances` WRITE;
/*!40000 ALTER TABLE `seances` DISABLE KEYS */;
INSERT INTO `seances` VALUES (1,_binary '\0','2024-11-25 09:00:00.000000','2024-11-25 12:00:00.000000','Introduction à Spring Boot','A101','Cours',1),(2,_binary '\0','2024-11-26 14:00:00.000000','2024-11-26 17:00:00.000000','Travaux pratiques Spring Boot','A102','TP',1),(3,_binary '\0','2024-11-27 09:00:00.000000','2024-11-27 12:00:00.000000','Optimisation de requêtes SQL','B201','Cours',2);
/*!40000 ALTER TABLE `seances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_pedagogiques`
--

DROP TABLE IF EXISTS `sessions_pedagogiques`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_pedagogiques` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `code` varchar(50) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `nom` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKsvj5454in5ousa2q4wrfx87lj` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_pedagogiques`
--

LOCK TABLES `sessions_pedagogiques` WRITE;
/*!40000 ALTER TABLE `sessions_pedagogiques` DISABLE KEYS */;
INSERT INTO `sessions_pedagogiques` VALUES (1,_binary '','S1-2024-2025','2024-09-01','2025-01-31','Semestre 1 - Année 2024/2025');
/*!40000 ALTER TABLE `sessions_pedagogiques` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specialites`
--

DROP TABLE IF EXISTS `specialites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specialites` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(100) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `nom` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKrt27hhdpexo711rpdgtbuwfqk` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specialites`
--

LOCK TABLES `specialites` WRITE;
/*!40000 ALTER TABLE `specialites` DISABLE KEYS */;
INSERT INTO `specialites` VALUES (1,'INFO','Spécialité Informatique et Technologies','Informatique'),(2,'GEST','Spécialité Gestion et Management','Gestion');
/*!40000 ALTER TABLE `specialites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `active` bit(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `email` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `role` enum('ADMIN','ETUDIANT','FORMATEUR') NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6dotkott2kjsp8vw4d0m25fb7` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,_binary '','2026-01-25 08:07:40.392440','admin@formation.tn','Admin','$2a$10$3Qp.75TE6pCDKc5K8nsQcO9pkOAHpUQijY3gkNUyioIpWvgfzDpu6','System','ADMIN','2026-01-25 08:07:40.392473'),(2,_binary '','2026-01-25 08:07:40.574325','formateur1@formation.tn','Benali','$2a$10$FnsurpehuHwoSy8bsCeY1upng6GJZJ9I3xZlhP4nvw39PccNQBtzS','Ahmed','FORMATEUR','2026-01-25 08:07:40.574343'),(3,_binary '','2026-01-25 08:07:40.684587','formateur2@formation.tn','Trabelsi','$2a$10$Ke8u37koC751L4pJe/HISeEzIFfXS/q0vkHaBn/D2ltTqt9ZWuzVG','Fatma','FORMATEUR','2026-01-25 08:07:40.684605'),(4,_binary '','2026-01-25 08:07:40.794713','formateur3@formation.tn','Khelifi','$2a$10$FfgwxofvPGLIFvX3vL589.D1VTvQKoCX2zvCSeDErrOCB/47WZNm6','Karim','FORMATEUR','2026-01-25 08:07:40.794731'),(5,_binary '','2026-01-25 08:07:40.950076','etudiant1@formation.tn','Gharbi','$2a$10$oU1gPtv83UeiWmbUpSyfDeb08YfqZFuT4SH2p9yJTAwRduB9CbWva','Mohamed','ETUDIANT','2026-01-25 08:07:40.950094'),(6,_binary '','2026-01-25 08:07:41.070448','etudiant2@formation.tn','Sassi','$2a$10$cB3rh4b.4XGCxUkUBOsb9OmNtx4UhXGlJ9qObqBz3bGLyV5VoZCFW','Amira','ETUDIANT','2026-01-25 08:07:41.070470'),(7,_binary '','2026-01-25 08:07:41.191999','etudiant3@formation.tn','Jebali','$2a$10$VZjxOoouUXrhyIajqbvifeZSYKodSrn55OeNEujlUFAS14Un17Q1e','Youssef','ETUDIANT','2026-01-25 08:07:41.192068'),(8,_binary '','2026-01-25 08:07:41.302220','aymenhadriche@gmail.com','Hadriche','$2a$10$OzYfRw1H3xd5ebw3m2tv9.DwXsD0AW0tygi7LdH1vsai7rw7/KNwu','Aymen','ETUDIANT','2026-01-25 08:07:41.302239');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'centre_formation'
--

--
-- Dumping routines for database 'centre_formation'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-25  8:14:37
